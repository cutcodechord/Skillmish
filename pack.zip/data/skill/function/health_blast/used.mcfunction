#> skill:health_blast/used
#

# 使用

# run
    scoreboard players set $strength player_motion.api.launch 10000
    summon snowball ~ ~ ~ {Tags:["healthblasttemp"]}
    execute at @s positioned ^ ^1.5 ^1.5 as @e[type=snowball,tag=healthblasttemp] run tp @s ~ ~ ~ ~ ~
    execute as @e[type=snowball,tag=healthblasttemp] at @s run function player_motion:api/launch_looking

# リセット
    advancement revoke @s only skill:process/health_blast/consume